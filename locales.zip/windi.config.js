export default {
  darkMode: 'class',
  // safelist: 'hidden',
}
