<template>
  <router-view></router-view>
  <div>
    <!-- confirm staff dialog -->
    <div v-if="usedEventId" class="fixed top-0 left-0 right-0 bottom-0 bg-black/50">
      <div class="absolute top-20 left-30 right-30 ">
        <div class="bg-white flex flex-wrap justify-center rounded-md border-5px border-red-500">
          <p class="text-50px p-5 text-stroke-sm uppercase w-full text-center">
            qrcode นี้ได้ทำการจ่ายเวชภัณฑ์เรียบร้อยไปแล้ว
          </p>
        </div>
      </div>
    </div>
    <div v-if="overSlot" class="fixed top-0 left-0 right-0 bottom-0 bg-black/50">
      <div class="absolute top-20 left-30 right-30 ">
        <div class="bg-white flex flex-wrap justify-center rounded-md border-5px border-red-500">
          <p class="text-50px p-5 text-stroke-sm uppercase w-full text-center">
            มีจำนวนช่องไม่พอสำหรับเวชภัณฑ์
          </p>
        </div>
      </div>
    </div>
    <div
      v-if="showConfirmStaff" class="fixed top-0 left-0 right-0 bottom-0 bg-black/50"
      @click.self="doCloseConfirmStaff"
    >
      <div class="absolute top-20 left-30 right-30 ">
        <div class="bg-white flex flex-wrap justify-center rounded-md border-5px border-red-500">
          <p v-if="staffType === 0" class="text-50px p-5 text-stroke-sm uppercase w-full text-center">
            โปรดสแกนบัตรพนักงาน
          </p>
          <p v-if="staffType === 1" class="text-50px p-5 text-stroke-sm uppercase w-full text-center">
            โปรดสแกนบัตรพนักงาน 2 ใบ
          </p>
          <div
            class="h-70 w-full" :style="{
              background:'url(https://img.freepik.com/free-vector/hospital-team-diverse-healthcare-staff-doctors_107791-11611.jpg?w=740&t=st=1665131255~exp=1665131855~hmac=11007d7e0aca44e88903943669c623cf4f90d89b781ec7878ef19fe453d8ef31) center  no-repeat',
              backgroundSize:'cover'
            }"
          ></div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { useAppStore } from '../store/app-store'
import { useMasterStore } from '../store/master-store'
import { useUiStore } from '../store/ui-store' // pinia
import { MqttClient } from '@/lib/mqtt'
import config from '../config'
import { mapState } from 'pinia'
import axios from '@/lib/axios'
export default {
  async beforeRouteEnter(to, from, next) {
    const appStore = useAppStore()
    if (!appStore.token) {
      return next('/setup')
    }
    axios.defaults.headers.common.Authorization = `Bearer ${appStore.token}`
    // load master
    await appStore.getToken()
    const masterStore = useMasterStore()
    await masterStore.fetchMaster()

    if (!masterStore.vendings.length) {
      return next('/setup')
    }

    masterStore.subscribeChange()

    let mqttConfig = masterStore.projects.find(x => x.id === appStore.projectId).config.mqtt
    MqttClient('default', {
      url: config.mqtt.url,
      options: {
        ...config.mqtt.options,
        ...mqttConfig,
      },
    })
    window.XenKiosk.motorOpen('dev/ttyS1')
    next()
  },
  data() {
    return {

    }
  },
  computed: {
    ...mapState(useUiStore, [
      'showConfirmStaff',
      'staffType',
      'overSlot',
    ]),
    ...mapState(useAppStore, [
      'usedEventId',
      'token',
    ]),
  },
  created() {
    this.timer = setInterval(async () => {
      let { data } = await axios.get('api/token')
      if (data.ok && data.token) {
        // appStore.token = data.token
        useAppStore().token = data.token
        axios.defaults.headers.common.Authorization = `Bearer ${data.token}`
      } else {
        useAppStore().token = ''
        delete axios.defaults.headers.common.Authorization
        this.$router.replace('/setup')
      }
    }, 60 * 60_000)
  },

  beforeUnmount() {
    clearInterval(this.timer)
  },

  methods: {
    doCloseConfirmStaff(e) {
      useUiStore().cancelConfirmStaff()
    },
  },
}
</script>
