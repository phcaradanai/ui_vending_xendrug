const cbLookup = {}

if (!window.XenKiosk) {
  window.XenKiosk = {
    motorOpen(port) {
      console.log('motorOpen', port)
    },
    motorSelect(ctrlId, start, end, orderId) {
      console.log('motorSelect', ctrlId, start, end, orderId)
      setTimeout(() => {
        let status = orderId % 2 === 0 ? '00' : '22'
        let message = 'FF0100000000280009' + String(orderId, 16).padStart(16, '0') + status + '5645'
        window.kioskEvent({
          type: 'motor:message',
          message,
        })
      }, 2_000)
    },
  }
}

window.XenKiosk.on = function (eventType, cb) {
  if (typeof cb !== 'function') {
    return null
  }
  let subId = new Date().getTime()
  if (!cbLookup[eventType]) {
    cbLookup[eventType] = {}
  }
  cbLookup[eventType][subId] = cb
  return subId
}

window.XenKiosk.off = function(eventType, subId) {
  if (cbLookup[eventType]?.[subId]) {
    delete cbLookup[eventType][subId]
  }
}

window.kioskEvent = function(event) {
  console.log('GOT: kioskEvent', event)
  if (!cbLookup[event.type]) {
    return
  }
  for (const cb of Object.values(cbLookup[event.type])) {
    try {
      cb(event)
    } catch (e) {
      console.log('kioskEvent callback error', e.message)
    }
  }
  return 'ok'
}
