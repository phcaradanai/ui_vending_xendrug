export default {
  name: 'XENTEMP',

  apiUrl: '/',

  secret: '[XT]',

  langList: [
    { value: 'th', text: 'ไทย' },
    { value: 'en', text: 'English' },
  ],

  yearFormatList: [
    { value: 'be', text: 'B.E.' },
    { value: 'ce', text: 'C.E.' },
  ],

  mqtt: {
    url: 'wss://xendrug-mqtt.xenex.io:443',
    options: {
      keepalive: 10,
    },
  },

  //   ขนาดของช่องใส่
  // ลึก 47 cm

  // หน้ากว้างรวม 70cm มี 24 ช่อง
  // กว้างช่องละ 70/24 = 2.91  ปัดลงเป็น 2.8 เผื่อ gap 0.1

  // 1 ช่อง ใช้ 2.8
  // 2 ช่อง ใช้ 2.8 * 2 + 0.1 = 5.7
  // 3 ช่อง ใช้ 2.8 * 3 + 0.1*2 = 8.6
  // 4 ช่อง ใช้ 2.8 * 4 + 0.1*3 = 11.5

  // ค่าพวกนี้ทำเป็น config ไว้ทั้งหมดนะครับ
  // เผื่อเปลี่ยนตู้เปลี่ยน spec ก็แค่ปรับ config ให้ตรงกับตู้
  vendingSize: {
    deep: 47,
    face: 70,
    slot: 2.8,
  },

  yearFormatDefault: 'be',
}
