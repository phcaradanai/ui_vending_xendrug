import { defineStore, mapState } from 'pinia'
import { MqttClient } from '@/lib/mqtt'
import { delay } from '@/lib/util'
import { useAppStore } from '@/store/app-store.js'
import { useMasterStore } from '../store/master-store'
import dayjs from 'dayjs'
export const useUiStore = defineStore('ui', {

  state() {
    return {
      toast: {
        show: false,
        message: '',
        duration: 1000,
        actions: [],
        timer: null,
      },
      showConfirmStaff: false,
      staffType: 0,
      showConfirmProduct: false,
      overSlot: false,
      masterStore: useMasterStore(),
    }
  }, // state
  getters: {
    ...mapState(useAppStore, ['projectCode', 'vendingCode']),

  },
  actions: {
    async confirmStaff(options) {
      console.log(options)
      if (options === 0) {
        this.staffType = 0
        return new Promise(resolve => {
          this.confirmStaffResolve = resolve
          let timeout = options?.timeout ?? 60000
          let timer = setTimeout(() => {
            this.cancelConfirmStaff()
          }, timeout)

          this.mqttClient = MqttClient('default', {})
          this.confirmStaffTopic = `xd/${this.projectCode}/${this.vendingCode}/reader`
          this.confirmStaffSubId = this.mqttClient.subscribe(this.confirmStaffTopic, (topic, payload) => {
            if (payload.refType === 'staff') {
              clearTimeout(timer)
              this.mqttClient.unsubscribe(this.confirmStaffTopic, this.confirmStaffSubId)
              this.showConfirmStaff = false

              resolve(payload)
            }
          })

          this.showConfirmStaff = true
        })
      }
      if (options === 1) {
        this.staffType = 1
        return new Promise(resolve => {
          let confirmPerson = []
          this.confirmStaffResolve = resolve
          let timeout = options?.timeout ?? 60000
          let timer = setTimeout(() => {
            this.cancelConfirmStaff()
          }, timeout)

          this.mqttClient = MqttClient('default', {})
          this.confirmStaffTopic = `xd/${this.projectCode}/${this.vendingCode}/reader`
          this.confirmStaffSubId = this.mqttClient.subscribe(this.confirmStaffTopic, async (topic, payload) => {
            if (payload.refType === 'staff') {
              if (payload.refCode === 'C10488') {
                confirmPerson[0] = payload
              }
              if (payload.refCode === 'BD0488') {
                confirmPerson[1] = payload
              }

              if (confirmPerson[0] !== undefined && confirmPerson[1] !== undefined) {
                clearTimeout(timer)
                this.mqttClient.unsubscribe(this.confirmStaffTopic, this.confirmStaffSubId)
                this.showConfirmStaff = false

                resolve(confirmPerson)
              }
            }
          })
          this.showConfirmStaff = true
        })
      }
      // return new Promise(resolve => {
      //   this.confirmStaffResolve = resolve
      //   let timeout = options?.timeout ?? 60000
      //   let timer = setTimeout(() => {
      //     this.cancelConfirmStaff()
      //   }, timeout)

      //   this.mqttClient = MqttClient('default', {})
      //   this.confirmStaffTopic = 'xd/0001/00010001/reader'
      //   this.confirmStaffSubId = this.mqttClient.subscribe(this.confirmStaffTopic, (topic, payload) => {
      //     console.log('GOT', payload)
      //     if (!payload.refType === 'staff') {
      //       console.log('not a staff')
      //       return
      //     }
      //     clearTimeout(timer)
      //     this.mqttClient.unsubscribe(this.confirmStaffTopic, this.confirmStaffSubId)
      //     this.showConfirmStaff = false

      //     resolve(payload)
      //   })

      //   this.showConfirmStaff = true
      // })
    },
    // confirmManage(options) {
    //   return new Promise(resolve => {
    //     let confirmPerson = []
    //     this.confirmStaffResolve = resolve
    //     let timeout = options?.timeout ?? 60000
    //     let timer = setTimeout(() => {
    //       this.cancelConfirmStaff()
    //     }, timeout)

    //     this.mqttClient = MqttClient('default', {})
    //     this.confirmStaffTopic = 'xd/0001/00010001/reader'
    //     this.confirmStaffSubId = this.mqttClient.subscribe(this.confirmStaffTopic, (topic, payload) => {
    //       console.log('GOT', payload)
    //       if (!payload.refType === 'staff') {
    //         console.log('not a staff')
    //         return
    //       }
    //       if (payload.refCode === 'C10488') {
    //         confirmPerson[0] = payload
    //       }
    //       if (payload.refCode === 'BD0488') {
    //         confirmPerson[1] = payload
    //       }

    //       if (confirmPerson[0] !== undefined && confirmPerson[1] !== undefined) {
    //         clearTimeout(timer)
    //         this.mqttClient.unsubscribe(this.confirmStaffTopic, this.confirmStaffSubId)
    //         this.showConfirmStaff = false
    //         resolve(confirmPerson)
    //       }
    //     })
    //     this.showConfirmStaff = true
    //   })
    // },
    confirmProduct(options) {
      return new Promise(resolve => {
        this.confirmProductResolve = resolve
        let timeout = options?.timeout ?? 60000
        let timer = setTimeout(() => {
          this.cancelConfirmProduct()
        }, timeout)

        this.mqttClient = MqttClient('default', {})
        this.confirmProductTopic = `xd/${this.projectCode}/${this.vendingCode}/reader`
        this.confirmProductSubId = this.mqttClient.subscribe(this.confirmProductTopic, (topic, payload) => {
          console.log('GOT', payload)
          if (!payload.refType === 'product') {
            console.log('not a product')
            return
          }
          clearTimeout(timer)
          this.mqttClient.unsubscribe(this.confirmProductTopic, this.confirmProductSubId)
          this.showConfirmProduct = false

          resolve(payload)
        })

        this.showConfirmProduct = true
      })
    },
    cancelConfirmStaff(options) {
      this.mqttClient?.unsubscribe(this.confirmStaffTopic, this.confirmStaffSubId)
      this.showConfirmStaff = false
      this.confirmStaffResolve = null
    },
    cancelConfirmProduct(options) {
      this.mqttClient?.unsubscribe(this.confirmProductTopic, this.confirmProductSubId)
      this.showConfirmProduct = false
      this.confirmProductResolve = null
    },
    showToast(message, duration, actions) {
      this.toast.message = message
      this.toast.duration = Math.min(duration ?? 3000, 3000)
      this.toast.actions = actions ?? [{ id: 'close', text: 'OK' }]
      this.toast.show = true
      this.toast.timer = setTimeout(() => {
        this.toast.show = false
      }, this.toast.duration)
    },
    colorLevel(category) {
      let color = ''
      if (category === 'warning') {
        color = 'yellow'
      } else if (category === 'danger') {
        color = 'red'
      } else {
        color = 'white'
      }
      return color
    },
    async overSlotOn() {
      this.overSlot = true
      await delay(1500)
      this.overSlot = false
    },
    compareExpDates(item, product) {
      let exp = 1
      try {
        exp = product.detail.config.expireDates
      } catch {
        exp = this.project.config.expireDates
      }
      let now = Date.parse(dayjs().format('YYYY-MM-DD'))
      let res = ''
      item.list.forEach(element => {
        let dayWarn = Date.parse(dayjs(element.expDate).subtract(exp, 'day'))
        if (Date.parse(dayjs(element.expDate).format('YYYY-MM-DD')) < now) {
          res = 'text-red-600 bg-white'
        } else if (dayWarn <= now) {
          res = 'text-yellow-400 bg-white'
        } else {
          res = 'hidden'
        }
      })
      return res
    },
    compareColor(element) {
      let exp = 1
      let product = element.selectedProduct
      console.log('element', element)
      try {
        exp = product.config.expireDates
      } catch {
        exp = this.project.config.expireDates
      }
      let now = Date.parse(dayjs().format('YYYY-MM-DD'))
      let res = ''

      let dayWarn = Date.parse(dayjs(element.exp).subtract(exp, 'day'))
      if (Date.parse(dayjs(element.exp).format('YYYY-MM-DD')) < now) {
        res = 'text-red-600 bg-white'
      } else if (dayWarn <= now) {
        res = 'text-yellow-400 bg-white'
      } else {
        res = 'hidden'
      }

      return res
    },
  }, // actions
})
