import { defineStore } from 'pinia'
import { useStorage } from '@vueuse/core'
import axios from '@/lib/axios.js'
import i18n from '@/lib/i18n.js'
import dayjs from 'dayjs'
import { delay } from '@/lib/util'
export const useAppStore = defineStore('app', {
  state() {
    return {
      token: useStorage('token', ''),
      lang: useStorage('lang', 'en'),
      theme: useStorage('theme', 'light'),
      showNav: false,
      onReady: true,
      usedEventId: false,
      projectCode: useStorage('projectCode', ''),
      projectId: useStorage('projectId', ''),
      vendingCode: useStorage('vendingCode', ''),
    }
  }, // state

  getters: {
  },

  actions: {
    toggleNav() {
      this.showNav = !this.showNav
    },

    setLang(lang) {
      i18n().global.locale.value = lang
      this.lang = lang
    },

    setToken(token) {
      this.token = token
      if (token) {
        axios.defaults.headers.common.Authorization = `Bearer ${token}`
      } else {
        delete axios.defaults.headers.common.Authorization
      }
    }, // setToken

    async fetchToken(req) {
      try {
        console.log('req', req)
        let { data } =
          await axios.post('/api/token', {
            req,
          },
          )

        if (data.ok && data.token) {
          this.setToken(data.token)
        }
      } catch (err) {
        console.log(err.message)
      }
    }, // fetchToken
    async getToken() {
      try {
        let { data } = await axios({
          method: 'get',
          url: '/api/token',
        })

        if (data.ok) {
          this.projectCode = data.pcode
          this.vendingCode = data.code
          this.projectId = data.pid
        }
      } catch (err) {
        console.log(err.message)
      }
    },
    onReadyOrNot(status) {
      this.onReady = status
      return status
    },
    async getEventId(data) {
      let res = await axios.get('/api/usedEventId', { params: { eventNo: data } },
      )
      if (res.data.ok !== 1) {
        this.usedEventId = true
        await delay(1500)
        await this.usedEventAlert()
      }
      return res
    },
    async usedEventAlert() {
      this.usedEventId = false
    },
  }, // actions
})
