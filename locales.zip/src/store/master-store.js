import { defineStore, mapState } from 'pinia'

import axios from '@/lib/axios.js'
import { genLookup, packToArray } from '@/lib/util.js'
import { useAppStore } from '@/store/app-store.js'
import { MqttClient } from '@/lib/mqtt'
import config from '../config'

export const useMasterStore = defineStore('master', {
  // arrow function recommended for full type inference
  state() {
    return {
      projects: [],
      vendings: [],
      products: [],
      staffs: [],
    }
  }, // state

  getters: {
    receptorLookup(state) {
      return genLookup(state.receptors, 'id')
    },
    ...mapState(useAppStore, ['projectCode']),
  }, // getters

  actions: {
    async fetchMaster() {
      try {
        let { data } = await axios({
          methods: 'GET',
          url: '/api/master',
          // headers: {
          //   Authorization: `Bearer ${useAppStore().token}`,
          // },
        })
        for (let tableName of Object.keys(data.data)) {
          if (!this[tableName]) {
            continue
          }
          this[tableName] = packToArray(data.data[tableName])
          // this[tableName] = data.data[tableName]
        }
      } catch (e) {
        console.log('error', e.message)
      }
    }, // fetchMaster

    async updateMaster(data) {
      await axios({
        method: 'POST',
        url: '/api/master',
        data,
      })
    }, // updateMaster

    subscribeChange() {
      let mqttConfig = this.projects.find(x => x.code === this.projectCode).config.mqtt
      // let mqttClient = MqttClient('default', {
      //   url: config.mqtt.url,
      //   options: {
      //     ...config.mqtt.options,
      //     mqttConfig,
      //   },
      // })
      let mqttClient = MqttClient('default', {
        url: config.mqtt.url,
        options: {
          ...config.mqtt.options,
          ...mqttConfig,
        },
      })
      mqttClient.subscribe(`xd/${this.projectCode}/master`, this.onChange)
    }, // subscribeChange

    onChange(topic, payload) {
      let obj = payload
      for (let table of Object.keys(obj)) {
        if (!this[table]) {
          continue
        }
        if (obj[table].upd?.length) {
          for (const data of obj[table].upd) {
            let index = this[table].findIndex(item => item.id === data.id)
            if (index >= 0) {
              this[table].splice(index, 1, { ...this[table][index], ...data }) // merge
            } else {
              this[table].push(data)
            }
          }
        }
        if (obj[table].del?.length) {
          for (const id of obj[table].del) {
            let index = this[table].findIndex(item => item.id === id)
            this[table][index].isActive = 'N'
          }
        }
      }
    },
  }, // actions
})
