<route lang="yaml">
meta:
  layout: public
</route>

<template>
  <div class="bg-black/50 h-[100vh]"></div>
  <div class="absolute flex flex-col justify-center items-center top-10 left-[40%] bg-white rounded-md p-2">
    <div class="bg-gray-200 w-full flex justify-center rounded-md p-2">
      SETUP
    </div>
    <div class="flex p-2 ">
      <p class="flex-grow flex justify-center items-center">
        vending-code :
      </p>
      <input class="w-1/2 flex " type="text" placeholder="xxxxxxxx" v-model="code">
    </div>
    <button class="p-2 bg-green-400 rounded-md" @click="doSave" :disabled="!isValid">
      SAVE
    </button>
  </div>
</template>
<script>
import { useAppStore } from '../store/app-store'

export default {
  data() {
    let appStore = useAppStore()
    let code = appStore.vendingCode
    return {
      appStore,
      code,
    }
  },

  computed: {
    isValid() {
      return (/^[0-9a-f]{8}$/i).test(this.code)
    },
  },

  methods: {
    async doSave() {
      console.log('save')
      // TODO: validate format
      // TODO: register vending or checking

      let req = { vendingCode: this.code }
      await this.appStore.fetchToken(req)
      this.$router.replace('/')
    },
  },
}

</script>
