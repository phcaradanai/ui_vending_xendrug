<route lang="yaml">
meta:
  layout: default
</route>

<template>
  <div
    class="flex flex-col gap-5 p-5 h-[100vh]" :style="{
      background:'#2477BF',
      backgroundImage: 'linear-gradient(180deg,#2477BF,#6595BF,#9AC7D9,#fff,#fff',
    }"
  >
    <div class="flex justify-end gap-4">
      <!-- <button
        class="leading-10 rounded-xl p-5 justify-center  uppercase shadow-md shadow-current bg-white opacity-5"
        :style="{
          border: '2px solid  #2477BF',
        }" @click="doTools"
      >
        <p class="text-stroke-sm  text-black  text-size-[30px]">
          เครื่องมือ
        </p>
      </button> -->
      <button
        class="leading-10 rounded-xl p-5 justify-center  uppercase shadow-md shadow-current bg-white " :style="{
          border: '2px solid  #2477BF',
        }" @click="doManage"
      >
        <p class="text-stroke-sm  text-black  text-size-[30px]">
          การจัดการ
        </p>
      </button>
    </div>
    <vending-display :config="vending.config" :items="items" @item-click="onItemClick">
      <template #item="{ item ,product}">
        <div>
          <div v-if="item.productId">
            <div class="flex h-49 ">
              <div
                class="w-full flex justify-center" :style="{
                  background:`url(${product.detail.config.imageUrl}) center no-repeat`,
                  backgroundSize:'cover',
                  borderRadius: '5px 5px 0 0',
                }"
              >
                <div
                  class="w-[26px] h-[26px] rounded-full flex justify-center items-center "
                  :class="[ uiStore.compareExpDates(item ,product)]"
                >
                  <div class="m-icon ">
                    priority_high
                  </div>
                </div>
              </div>
            </div>
            <div
              class="flex justify-center" :style="
                {
                  background: `${product.color}`,
                }"
            >
              <p class="uppercase text-stroke-sm text-transparent">
                {{ product.detail.config.category }}
              </p>
            </div>
            <div
              class="flex justify-center p-2 " :style="{
                background:'#C9EBF2',
                borderRadius: '0 0 5px 5px',
              }"
            >
              <p class="uppercase text-stroke-md ">
                {{ item.list.length }}
              </p>
            </div>
          </div>

          <div v-else>
            &nbsp;
          </div>
        </div>
      </template>
    </vending-display>
    <vending-slot-preview v-if="detail" :select-item="selectedItem" @close-preview="closePreview"></vending-slot-preview>
    <vending-pay-setup
      v-if="paySlotItem" :items="items" :payload-qr="payloadQr"
      :confirm-product-topic-id="{confirmProductTopic,confirmProductSubId}" @cancel-pay="doCancelPay"
      @qr-on-product="doQrProduct"
    >
    </vending-pay-setup>
    <div
      class="flex flex-wrap flex-col h-100 " :style="{
        background:'url(https://img.freepik.com/free-vector/pharmacy-typographic-header-pharmacist-preparing-selling-drugs-bottle-box-disease-treatment-healthcare-medical-treatment-concept-isolated-vector-illustration_613284-1356.jpg?w=1380&t=st=1665130867~exp=1665131467~hmac=029c3c01de6b3ad7fa79376812a7abc571bf696ae6abe9d0c138fa5d9c6d1a31) center no-repeat',
        backgroundSize:'cover'
      }"
    >
      <div class="bg-gray-500/30  rounded-md flex justify-center">
        <p class="text-50px p-5 text-center animate-charcter">
          สแกน qrcode เวชภัณฑ์เพื่อทำรายการจ่ายยา
        </p>
      </div>

      <div class="flex flex-grow justify-end items-end ">
        <button
          class="flex  items-center gap-2  p-5 bottom-5 rigth-5  leading-10 rounded-xl justify-center shadow-md shadow-current bg-white "
          :style="{
            border: '2px solid #FF3333',
          }"
        >
          <div class="m-icon text-red-500 text-size-[35px]">
            warning
          </div>
          <p class="text-stroke-sm  text-dark-800 text-size-[30px]">
            เปิดฉุกเฉิน
          </p>
        </button>
      </div>
    </div>
  </div>
</template>

<script>
// import
import config from '@/config'
import { useUiStore } from '../store/ui-store'
import { useAppStore } from '@/store/app-store'
import { useMasterStore } from '../store/master-store'
import { MqttClient } from '@/lib/mqtt'
import { mapState } from 'pinia'
import dayjs from 'dayjs'

export default {
  components: {

  },
  data() {
    const masterStore = useMasterStore()
    const appStore = useAppStore()
    const uiStore = useUiStore()
    let items = JSON.parse(JSON.stringify(masterStore.vendings.find(element => element.code === appStore.vendingCode).info?.items))
    return {
      items,
      masterStore,
      appStore,
      uiStore,
      paySlotItem: false,
      payloadQr: null,
      detail: false,
    }
  }, // data
  computed: {
    ...mapState(useAppStore, ['projectCode', 'vendingCode']),
    vending() {
      return this.masterStore.vendings.find(element => element.code === this.vendingCode)
    },
    project() {
      return this.masterStore.projects.find(element => element.code === this.projectCode)
    },
    products() {
      return this.masterStore.products
    },
  },
  watch: {

  }, // watch
  created() {

  }, // computed
  mounted() {
    // let ready = this.appStore.onReadyOrNot(true)
    this.doRefresh()
    this.doQrProduct()
  },
  async beforeMount() {
    // 1920 1080/2 =540

  }, // mounted
  unmounted() {
    this.mqttClient.unsubscribe(this.confirmProductTopic, this.confirmProductSubId)
  },
  methods: {
    async doManage() {
      // confirm staff card??
      this.mqttClient.unsubscribe(this.confirmProductTopic, this.confirmProductSubId)
      let staff = await useUiStore().confirmStaff(0)
      if (staff.refType === 'staff') {
        await this.$router.push('/manage')
      }
    },
    // doTools() {
    //   this.$router.push('/tools')
    // },
    doCancelPay() {
      this.items = JSON.parse(JSON.stringify(this.vending.info?.items))
      this.paySlotItem = false
    },
    doRefresh() {
      let ready = this.appStore.onReadyOrNot(true)
      this.mqttClient = MqttClient('default', {})
      this.updateUi = `xd/${this.projectCode}/${this.vendingCode}/update`
      this.updateUiSubId = this.mqttClient.subscribe(this.updateUi, (topic, payload) => {
        if (ready === payload.update) {
          window.location.reload()
        }
      },
      )
    },
    doQrProduct() {
      this.mqttClient = MqttClient('default', {})
      this.confirmProductTopic = `xd/${this.projectCode}/${this.vendingCode}/reader`
      this.confirmProductSubId = this.mqttClient.subscribe(this.confirmProductTopic, (topic, payload) => {
        if (payload.refType === 'product') {
          this.payloadQr = payload
          this.paySlotItem = true
        }
      },
      )
    },
    onItemClick({ item }) {
      if (item.productId !== 0) {
        console.log('item', item)
        let product = this.products.find(x => x.id === item.productId)
        item.product = { detail: {} }
        item.product.detail = product
        console.log('item', item)
        this.selectedItem = item
        this.detail = !this.detail
      }
    },
    closePreview() {
      this.detail = !this.detail
    },

  }, // method
}
</script>

<style scoped>
.animate-charcter {
  text-transform: uppercase;
  background-image: linear-gradient(-225deg,
      #231557 0%,
      #44107a 29%,
      #ff1361 67%,
      #fff800 100%);
  background-size: auto auto;
  background-clip: border-box;
  background-size: 200% auto;
  color: #fff;
  background-clip: text;
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  animation: textclip 2s linear infinite;
  display: inline-block;
}

@keyframes textclip {
  to {
    background-position: 200% center;
  }
}
</style>
