<template>
  <div>
    <div>TOOLS</div>
    <div class="flex gap-3">
      <div class="flex gap-3 border-1 px-3 items-center">
        CTRL: <input v-model="motorCtrl" type="number" :min="0" :max="ctrlMax" class="w-20">
        FROM: <input v-model="motorStart" type="number" :min="0" :max="motorMax" class="w-20">
        TO: <input v-model="motorEnd" type="number" :min="motorStart" :max="motorMax" class="w-20">
        <button class="border-1 rounded-md px-3 py-2 bg-blue-100 min-w-50" @click="doMotorSelect">
          MOTOR SELECT
        </button>
        <div class="w-10 h-10 rounded-full" :class="[motorStatus === 0 ? 'bg-gray-200' : (motorStatus === 1 ? 'bg-green-400' : 'bg-red-400')]"></div>
      </div>
    </div>
    <div>
      Result:
      <div class="inline-flex gap-2">
        <div v-for="(v, k) in motorResult" :key="k">
          {{ k }}: {{ k === 'payload' ? v : v.toString(16) }}
        </div>
      </div><span></span>
    </div>
    <div>
      <textarea v-model="message" rows="20"></textarea>
    </div>
  </div>
</template>
<script>
export default {
  data() {
    return {
      motorCtrl: 0,
      motorStart: 0,
      motorEnd: 0,
      motorMax: 23,
      ctrlMax: 4,
      refNumber: 0,
      message: '',
      motorResult: null,
      motorStatus: 0,
    }
  },

  watch: {
    motorStart(newValue) {
      console.log('motorStart')
      if (newValue > this.motorEnd) {
        this.motorEnd = newValue
      }
    },
    motorEnd(newValue) {
      console.log('motorEnd')
      if (newValue < this.motorStart) {
        this.motorStart = newValue
      }
    },
  },

  created() {
    this.subId = window.XenKiosk.on('motor:message', (event) => {
      this.message += '\n' + event.message
      this.motorResult = this.parseMotorMessage(event.message)
      console.log(this.motorResult)
      if (this.motorResult?.payload?.status === 0) {
        this.motorStatus = 1
      } else {
        this.motorStatus = -1
      }
      clearTimeout(this.motorStatusTimer)
      this.motorStatusTimer = setTimeout(() => {
        this.motorStatus = 0
      }, 10_000)
    })
  },

  beforeUnmount() {
    window.XenKiosk.off('motor:message', this.subId)
  },

  methods: {
    doMotorSelect() {
      console.log('motorSelect')
      clearTimeout(this.motorStatusTimer)
      this.motorStatus = 0
      this.refNumber = new Date().getTime()
      window.XenKiosk.motorSelect(this.motorCtrl, this.motorStart, this.motorEnd, this.refNumber)
    },

    parseMotorMessage(message) {
      // FF01000000002800090001665467792795225645
      // [f][v] [addr/board][cmd][len][payload(len)]           [check]
      // FF  01 00000000    28   0009 [0000 0000 0000 0000 24] [3e 18]
      let firmware = parseInt(message.substr(0, 2), 16)
      let version = parseInt(message.substr(2, 2), 16)
      let ctrl = parseInt(message.substr(4, 8), 16)
      let cmd = parseInt(message.substr(12, 2), 16)
      let len = parseInt(message.substr(14, 4), 16)
      let payload = {
        refId: parseInt(message.substr(18, 16)),
        status: parseInt(message.substr(34, 2), 16),
      }
      let crc = parseInt(message.substr(36, 4), 16)

      let out = {
        firmware,
        version,
        ctrl,
        cmd,
        len,
        payload,
        crc,
      }

      return out
    },
  },
}
</script>
