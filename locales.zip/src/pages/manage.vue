<template>
  <div
    class="flex flex-col gap-5 p-5 h-[100vh] " :style="{
      background:'#2477BF',
      backgroundImage: 'linear-gradient(380deg,#2477BF,#6595BF,#9AC7D9,#fff,#fff',
    }"
  >
    <div class="flex justify-end">
      <button
        class="leading-10 rounded-xl p-2 justify-center bg-white shadow-current shadow-md" :style="{
          border: '2px solid #FF3333',
        }" @click="outManage"
      >
        <p class="text-dark-800 text-size-[30px] uppercase text-stroke-sm">
          ออกจากหน้าจัดการ
        </p>
      </button>
    </div>
    <vending-display :config="vending.config" :items="items" :products="products" @item-click="onItemClick">
      <template #item="{ item ,product}">
        <div>
          <div v-if="item.productId">
            <div class="flex h-48">
              <div
                class="w-full flex justify-center" :style="{
                  background:`url(${product.detail.config.imageUrl}) center no-repeat`,
                  backgroundSize:'cover',
                  borderRadius: '5px 5px 0 0',
                }"
              >
                <div
                  class="w-[26px] h-[26px] rounded-full flex justify-center items-center "
                  :class="[ uiStore.compareExpDates(item ,product)]"
                >
                  <div class="m-icon ">
                    priority_high
                  </div>
                </div>
              </div>
            </div>
            <div
              class="flex justify-center" :style="
                {
                  background: `${product.color}`,
                }"
            >
              <p class="uppercase text-stroke-sm text-transparent">
                {{ product.detail.config.category }}
              </p>
            </div>
            <div
              class="flex justify-center p-2" :style="{
                borderRadius: '0 0 5px 5px',
                background:'#C9EBF2'
              }"
            >
              <p class="uppercase text-stroke-md ">
                {{ item.list.length }}
              </p>
            </div>
          </div>
          <div v-else>
            &nbsp;
          </div>
        </div>
      </template>
    </vending-display>
    <div class="flex flex-col flex-wrap h-100 rounded-md overflow-auto">
      <div
        class="flex flex-wrap justify-center h-full rounded-md p-2 w-1/2 overflow-auto hideScroll" :style="{
          background:'#85C1E9'
        }"
      >
        <p class="bg-white h-min p-2 rounded-md text-20px w-full text-center ">
          รายการเพิ่มมาใหม่
        </p>
        <div v-for="item,index in summaryItem.add" :key="index" class="flex flex-wrap gap-2 p-2">
          <!-- <div class="flex gap-2  p-2 rounded-md"> -->
          <p> ชื่อยา :{{ item.info.displayName }}</p>
          <p> หมายเลขล็อต :{{ item.lotNo }}</p>
          <p> วันหมดอายุ :{{ item.expDate }}</p>
          <p> จำนวน :{{ item.qty }}</p>
          <!-- </div> -->
        </div>
      </div>
      <div
        class="h-1/2 flex flex-wrap justify-center p-2 rounded-md w-1/2 overflow-auto hideScroll" :style="{
          background:'#FCF3CF '
        }"
      >
        <p class="bg-white h-min p-2 rounded-md text-15px w-full text-center ">
          รายการหมดอายุ
        </p>

        <div v-for="item,index in summaryItem.expired" :key="index" class="flex flex-wrap gap-2 p-2">
          <!-- {{ item }} -->
          <!-- <div class="flex gap-2  p-2 rounded-md "> -->
          <p> ชื่อยา : {{ item.info.displayName }}</p>
          <p> หมายเลขล็อต : {{ item.lotNo }}</p>
          <p> วันหมดอายุ : {{ item.expDate }}</p>
          <p> จำนวน : {{ item.qty }}</p>
          <!-- </div> -->
        </div>
      </div>
      <div
        class="h-1/2 flex flex-wrap justify-center p-2 rounded-md w-1/2 overflow-auto hideScroll" :style="{
          background:'#CCD1D1'
        }"
      >
        <p class="bg-white h-min p-2 rounded-md text-20px w-full text-center">
          รายการสูญหาย
        </p>
        <div v-for="item,index in summaryItem.missing" :key="index" class="flex flex-wrap gap-2 p-2">
          <!-- <div class="flex  gap-2 p-2 rounded-md"> -->
          <p> ชื่อยา :{{ item.info.displayName }}</p>
          <p> หมายเลขล็อต :{{ item.lotNo }}</p>
          <p> วันหมดอายุ :{{ item.expDate }}</p>
          <p> จำนวน :{{ item.qty }}</p>
          <!-- </div> -->
        </div>
      </div>
    </div>
    <div class="flex gap-20 justify-center ">
      <button class="bg-green-300 rounded-md p-5 shadow-current shadow-md" @click="doConfirm">
        <p>
          ยืนยัน
        </p>
      </button>
      <button class="bg-red-300 rounded-md p-5 shadow-current shadow-md" @click="doCancel">
        <p>
          ยกเลิก
        </p>
      </button>
    </div>
    <div v-if="popManage" class="fixed top-0 bottom-0 left-0 right-0 h-[100vh] bg-dark-50/50">
      <vending-slot-manage
        v-if="popHave === 1" :vending-item="selectedItem" :products="products"
        @close="onSlotManageClose" @changing="changeOn"
      >
      </vending-slot-manage>
      <vending-product-selector
        v-if="popHave === 0" :change-product="selectedChangeProduct" @close="onSlotManageClose"
        @changed="changingProduct" @do-fill-back="onFillBack"
      >
      </vending-product-selector>
    </div>
    <vending-fill-back v-if="fillBack" :vending-item="selectedItem" @cancel-fill-back="offFillBack"></vending-fill-back>
  </div>
</template>
<script>
import axios from '../lib/axios'
import { useMasterStore } from '../store/master-store'
import { useUiStore } from '../store/ui-store'
import { useAppStore } from '@/store/app-store'
import { mapState } from 'pinia'
import dayjs from 'dayjs'
export default {
  data() {
    const masterStore = useMasterStore()
    const appStore = useAppStore()
    const uiStore = useUiStore()
    let items = JSON.parse(JSON.stringify(masterStore.vendings.find(x => x.code === appStore.vendingCode).info?.items))
    let startTimeAtManage = dayjs().format('YYYY-MM-DD HH:mm:ss')

    return {
      masterStore,
      appStore,
      uiStore,
      items,
      selectedItem: null,
      popHave: 0,
      popManage: false,
      showStockSetup: false,
      selectedChangeProduct: null,
      startTimeAtManage,
      fillBack: false,
    }
  },
  computed: {
    ...mapState(useUiStore, [
      'showConfirmStaff',
    ]),
    ...mapState(useAppStore, ['projectCode', 'vendingCode']),
    vending() {
      return this.masterStore.vendings.find(x => x.code === this.vendingCode)
    },
    project() {
      return this.masterStore.projects.find(x => x.code === this.projectCode)
    },
    products() {
      return this.masterStore.products
    },
    summaryItem() {
      return this.compareItems(this.vending.info.items, this.items)
    },

  },
  watch: {

  },
  created() {
    this.appStore.onReadyOrNot(false)
  },
  beforeUnmount() {
  },
  mounted() {

  },

  methods: {
    async doConfirm() {
      // todo confirm to save
      // wait for confirm  scan 2 id
      let staff = await useUiStore().confirmStaff(1)
      console.log('staff', staff)
      if (!staff) {
        return
      }
      await this.doSave(staff)
    },
    doCancel() {
      // todo confirm to cancel
      this.items = JSON.parse(JSON.stringify(this.vending.info?.items))
    },
    onSlotManageClose(stock) {
      this.popManage = false
      if (stock) {
        this.selectedItem.list = stock.slice(0)
      }
      this.selectedChangeProduct = null
    },
    changeOn(product) {
      this.popHave = 0
      this.selectedChangeProduct = product
    },
    closeOn() {
      this.showStockSetup = !this.showStockSetup
    },
    async onItemClick({ item }) {
      // sort date
      // TODO: check size
      // find product
      if (this.fillBack) {
        if (item.productId !== 0) {
          return
        }
        if (item.productId === 0) {
          let product = this.findProduct(parseInt(this.selectedItem.productId))
          let dupicateSlot = []
          let sum = Math.ceil(product.config.widthMm / this.vending.config.slotWidthMm)
          this.items.forEach(element => {
            for (let num = 0; num < sum; num++) {
              if (item.row === element.row) {
                if (item.col + num - 1 === element.col - 1) {
                  dupicateSlot.push(element)
                }
              }
            }
          })
          if (!dupicateSlot.length) {
            item.list = this.selectedItem.list
            item.productId = this.selectedItem.productId
            item.numCol = sum
            this.items.push(item)
            this.items.forEach(data => {
              if (data.col === this.selectedItem.col && data.row === this.selectedItem.row) {
                let index = this.items.indexOf(data)
                if (index !== -1) {
                  this.items.splice(index, 1)
                }
              }
            })
            this.fillBack = false
            this.popHave = 1
          } else {
            await useUiStore().overSlotOn()
          }
        }
      }
      if (!this.fillBack) {
        if (item.productId === 0) {
          //  todo select a prodect id from user
          this.selectedItem = item
          this.popHave = 0
          this.popManage = true
          if (!item.productId) {
            return
          }
          // TODO: check size
        }

        this.selectedItem = this.items.find(x => x.productId === item.productId && x.col === item.col && x.row === item.row)
        this.popManage = true
        this.popHave = 1
      }
    },

    async doSave(staff) {
      let beforeItem = { items: this.vending.info.items }
      let afterItem = { items: this.items }
      let confirmPerson = { staffs: staff }

      await axios.post('/api/vending/stock', {
        id: this.vending.id,
        info: {
          items: this.items,
        },
        ts: {
          projectId: this.project.id,
          type: 'M',
          beforeItem,
          afterItem,
          diffItem: this.summaryItem,
          startTime: this.startTimeAtManage,
          endTime: dayjs().format('YYYY-MM-DD HH:mm:ss'),
          confirmPerson,
        },
      },
      )
    },
    compareItems(beforeItem, afterItem) {
      let res = {
        add: [],
        expired: [],
        missing: [],
      }
      let today = dayjs().format('YYYY-MM-DD')
      let beforeSum = {}
      for (let slot of beforeItem) {
        for (let item of slot.list) {
          let key = slot.productId + ':' + item.lotNo + ':' + item.expDate

          if (!beforeSum[key]) {
            beforeSum[key] = 1
          } else {
            beforeSum[key]++
          }
        }
      }
      let afterSum = {}
      for (let slot of afterItem) {
        for (let item of slot.list) {
          let key = slot.productId + ':' + item.lotNo + ':' + item.expDate
          if (!afterSum[key]) {
            afterSum[key] = 1
          } else {
            afterSum[key]++
          }
        }
      }
      for (let beforeKey of Object.keys(beforeSum)) {
        afterSum[beforeKey] = afterSum[beforeKey] ?? 0
        let [productId, lotNo, expDate] = beforeKey.split(':')
        if (afterSum[beforeKey] > beforeSum[beforeKey]) {
          res.add.push({
            productId,
            lotNo,
            expDate,
            qty: afterSum[beforeKey] - beforeSum[beforeKey],
          })
        } else if (afterSum[beforeKey] < beforeSum[beforeKey]) {
          if (expDate <= today) {
            let info = this.findProduct(parseInt(productId))
            res.expired.push({
              productId,
              lotNo,
              expDate,
              qty: beforeSum[beforeKey] - afterSum[beforeKey],
              info,
            })
          } else {
            let info = this.findProduct(parseInt(productId))
            res.missing.push({
              productId,
              lotNo,
              expDate,
              qty: beforeSum[beforeKey] - afterSum[beforeKey],
              info,
            })
          }
        }

        delete afterSum[beforeKey]
      }
      for (let afterKey of Object.keys(afterSum)) {
        let [productId, lotNo, expDate] = afterKey.split(':')
        let info = this.findProduct(parseInt(productId))
        res.add.push({
          productId,
          lotNo,
          expDate,
          qty: afterSum[afterKey],
          info,
        })
      }
      return res
    },
    outManage() {
      this.$router.replace('/')
    },
    async changingProduct({ product, type }) {
      let sum = Math.ceil(product.config.widthMm / this.vending.config.slotWidthMm)
      if (this.selectedItem.col + sum > this.vending.config.cols) {
        return
      }
      let dupicateSlot = []
      this.items.forEach(element => {
        for (let num = 0; num < sum; num++) {
          if (this.selectedItem.row === element.row) {
            if (this.selectedItem.col + num - 1 === element.col - 1) {
              dupicateSlot.push(element)
            }
          }
        }
      })
      if (type === 0) {
        if (!dupicateSlot.length) {
          this.selectedItem.list = []
          this.selectedItem.productId = product.id
          this.selectedItem.numCol = sum
          this.items.push(this.selectedItem)
          this.popHave = 1
        } else {
          await useUiStore().overSlotOn()
        }
      } else {
        this.selectedItem.list = []
        this.selectedItem.productId = product.id
        this.selectedItem.numCol = sum
        this.items.push(this.selectedItem)
        this.popHave = 1
      }
    },
    findProduct(id) {
      let productSelected = this.masterStore.products.find(x => x.id === id)
      return productSelected
    },
    onFillBack() {
      this.fillBack = true
    },
    offFillBack() {
      this.fillBack = false
    },

  },

}
</script>

<style>
.hideScroll::-webkit-scrollbar {
  display: none;
}
</style>
