<template>
  <div class="fixed top-0 bottom-0 left-0 right-0 h-[100vh] bg-dark-50/50 overflow-auto">
    <div v-if="onDrop" class="lds-ring">
      <div></div>
      <div></div>
      <div></div>
      <div></div>
    </div>
    <div
      v-if="!onDrop" class="w-[50vh] absolute top-10 left-1/2 rounded-md flex flex-col gap-10 bg-white "
      style="transform: translateX(-50%);"
    >
      <div class="flex justify-center text-30px p-5 bg-blue-100 rounded-md ">
        <p>
          รายการที่ต้องการ
        </p>
      </div>

      <div v-for="(payItem,index) in listPayItems" :key="index">
        <div class="flex flex-wrap p-5 gap-5 bg-gray-100 justify-center rounded-md ">
          <div
            class="h-30 w-1/5 rounded-md " :style="
              {
                background: `url(${payItem.product.config.imageUrl}) center center no-repeat`,
                backgroundSize: 'cover',
              }
            "
          >
          </div>
          <div class="flex flex-wrap text-30px items-center flex-grow ">
            <p class="w-full">
              {{ payItem.product.displayName }}
            </p>
            <p class="w-full">
              จำนวน: {{ payItem.qty }}
            </p>
          </div>
          <button class="flex flex-wrap text-30px items-center " @click="doRemove(payItem,index)">
            <p class="border-5px p-5 rounded-md border-red-500">
              ลบรายการนี้
            </p>
          </button>
        </div>
      </div>
      <div class="flex justify-center gap-10 p-2 text-30px ">
        <div class="rounded-md p-5 flex items-center gap-2 ">
          <p class="rainbow">
            สแกนบัตรพนักงานเพื่อยืนยันรายการ
          </p>
          <div class="bg-red-300 rounded-md p-5 ">
            <button @click="cancelPay">
              ยกเลิก
            </button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import dayjs from 'dayjs'
import axios from '../lib/axios'
import { useUiStore } from '../store/ui-store'
import { useMasterStore } from '../store/master-store'
import { useAppStore } from '@/store/app-store'
import { MqttClient } from '@/lib/mqtt'
import { delay } from '@/lib/util'
import { mapState } from 'pinia'

export default {
  props: {
    payloadQr: {
      type: Object,
      default() {
        return {}
      },
    },
    items: {
      type: Array,
      default() {
        return []
      },
    },
    confirmProductTopicId: {
      type: Object,
    },
  },
  emits: ['cancel-pay', 'qrOnProduct'],
  data() {
    const masterStore = useMasterStore()
    const appStore = useAppStore()
    let startTime = dayjs().format('YYYY-MM-DD HH:mm:ss')
    let cloneItem = JSON.parse(JSON.stringify(masterStore.vendings.find(x => x.code === appStore.vendingCode).info?.items))
    console.log(startTime)
    return {
      listPayItems: [],
      masterStore,
      changerSlot: JSON.parse(JSON.stringify(this.items)),
      message: '',
      motorResult: null,
      motorStatus: 0,
      onDrop: false,
      startTime,
      appStore,
      tsEvenIds: [],
      cloneItem,
    }
  },
  computed: {
    ...mapState(useAppStore, ['projectCode', 'vendingCode']),
    vending() {
      return this.masterStore.vendings.find(x => x.code === this.vendingCode)
    },
    project() {
      return this.masterStore.projects.find(x => x.code === this.projectCode)
    },
  },
  beforeCreate() {

  },
  // data
  mounted() {
    this.appStore.onReadyOrNot(false)
    this.qrOnProducts(this.payloadQr)
    this.mqttClient = MqttClient('default', {})
    this.confirmProductTopic = `xd/${this.projectCode}/${this.vendingCode}/reader`
    this.confirmProductSubId = this.mqttClient.subscribe(this.confirmProductTopic, async (topic, payload) => {
      if (payload.refType === 'product') {
        this.qrOnProducts(payload)
      }
      if (payload.refType === 'staff') {
        await this.doSave(payload)
      }
    },
    )
  },
  unmounted() {
    this.appStore.onReadyOrNot(true)
    window.XenKiosk.off('motor:message', this.subId)
    this.mqttClient.unsubscribe(this.confirmProductTopic, this.confirmProductSubId)
    this.$emit('qrOnProduct')
  },
  methods: {
    async qrOnProducts(product) {
      // todo confirm to save
      // wait for confirm  scan 2 id
      let usedEventId = await this.appStore.getEventId(product.refInfo.eventId)
      if (usedEventId.data.ok !== 1) {
        return
      }
      let productSelected = this.masterStore.products.find(x => x.code === product.refCode)
      let allShifts = []
      for (let i = 0; i < product.refInfo.qty; i++) {
        this.items.forEach(element => {
          if (element.productId === product.refId) {
            element.list.sort((a, b) => Date.parse(a.expDate) - Date.parse(b.expDate))
            allShifts.push(element.list[i])
          }
        })
      }
      allShifts.sort((a, b) => Date.parse(a.expDate) - Date.parse(b.expDate))
      let cloneShift = allShifts.slice(0)
      cloneShift = cloneShift.filter(function (element) {
        return element !== undefined
      })
      let lengthItem = cloneShift.length
      if (lengthItem - product.refInfo.qty < 0) {
        return
      }
      let oj = {}
      oj.product = productSelected
      oj.item = []
      oj.slot = []
      oj.eventId = product.refInfo.eventId
      oj.qty = product.refInfo.qty
      for (let i = 0; i < product.refInfo.qty; i++) {
        let expDate = allShifts.shift()
        if (!expDate) {
          return
        }
        oj.item.push(expDate)
        lengthItem--
        let run = true
        this.items.forEach(element => {
          const result = element.list.indexOf(expDate)
          if (result > -1) {
            if (run) {
              oj.slot.push({
                start: element.col,
                end: element.col + element.numCol - 1,
                ctrl: element.row,
              })
              element.list.splice(0, 1)
              run = false
            }
          }
        })
      }
      this.listPayItems.push(oj)
    },
    async doSave(staff) {
      let beforeItem = { items: this.vending.info.items }
      let afterItem = { items: this.items }
      let confirmPerson = { staffs: staff }
      let summaryItem = { success: '', detail: this.listPayItems }
      for (let round = 0; round < this.listPayItems.length; round++) {
        this.motorStatus = 0
        for (let item = 0; item < this.listPayItems[round].item.length; item++) {
          await this.motorSelect(this.listPayItems[round].slot[item].ctrl, this.listPayItems[round].slot[item].start, this.listPayItems[round].slot[item].end, new Date().getTime())
          this.onDrop = true
          this.subId = window.XenKiosk.on('motor:message', async (event) => {
            this.message += '\n' + event.message
            this.motorResult = this.parseMotorMessage(event.message)
            console.log(this.motorResult)
            if (this.motorResult?.payload?.status === 0) {
              this.motorStatus = 1
              this.upEventId(this.listPayItems[round].eventId)
            } else {
              this.motorStatus = 0
            }
          })
          summaryItem.success = this.motorStatus
          await axios.post('/api/vending/stock', {
            id: this.vending.id,
            info: {
              items: this.items,
            },
            ts: {
              projectId: this.project.id,
              type: 'D',
              beforeItem,
              afterItem,
              diffItem: summaryItem,
              startTime: this.startTime,
              endTime: dayjs().format('YYYY-MM-DD HH:mm:ss'),
              confirmPerson,
            },
          },
          )
          await delay(5000)
        }
      }
      this.onDrop = false
      this.cancelPay()
    },
    doRemove(payItem, index) {
      // todo confirm
      for (let i = 0; i < payItem.slot.length; i++) {
        let col = payItem.slot[i].start
        let row = payItem.slot[i].ctrl
        let numCol = payItem.slot[i].end - payItem.slot[i].start + 1
        this.items.forEach(element => {
          if (element.col === col && element.row === row && element.numCol === numCol) {
            element.list.push(payItem.item[i])
          }
        })
      }
      this.listPayItems.splice(index, 1)
    },
    cancelPay() {
      this.listPayItems = []
      this.$emit('cancel-pay', [])
    },
    async motorSelect(ctrl, start, end, order) {
      await window.XenKiosk.motorSelect(ctrl, start, end, order)
    },
    parseMotorMessage(message) {
      // FF01000000002800090001665467792795225645
      // [f][v] [addr/board][cmd][len][payload(len)]           [check]
      // FF  01 00000000    28   0009 [0000 0000 0000 0000 24] [3e 18]
      let firmware = parseInt(message.substr(0, 2), 16)
      let version = parseInt(message.substr(2, 2), 16)
      let ctrl = parseInt(message.substr(4, 8), 16)
      let cmd = parseInt(message.substr(12, 2), 16)
      let len = parseInt(message.substr(14, 4), 16)
      let payload = {
        refId: parseInt(message.substr(18, 16)),
        status: parseInt(message.substr(34, 2), 16),
      }
      let crc = parseInt(message.substr(36, 4), 16)

      let out = {
        firmware,
        version,
        ctrl,
        cmd,
        len,
        payload,
        crc,
      }

      return out
    },
    async upEventId(eventNo) {
      await axios.post('/api/usedEventId', {
        eventNo,
      },
      )
    },

  },
}
</script>

<style>
.rainbow {
  position: relative;
  z-index: 0;

  border-radius: 10px;
  overflow: hidden;
  padding: 2rem;

  &::before {
    content: '';
    position: absolute;
    z-index: -2;
    left: -50%;
    top: -50%;
    width: 200%;
    height: 200%;
    background-color: #399953;
    background-repeat: no-repeat;
    background-size: 50% 50%, 50% 50%;
    background-position: 0 0, 100% 0, 100% 100%, 0 100%;
    background-image: linear-gradient(#399953, #399953), linear-gradient(#fbb300, #fbb300), linear-gradient(#d53e33, #d53e33), linear-gradient(#377af5, #377af5);
    animation: rotate 4s linear infinite;
  }

  &::after {
    content: '';
    position: absolute;
    z-index: -1;
    left: 6px;
    top: 6px;
    width: calc(100% - 12px);
    height: calc(100% - 12px);
    background: white;
    border-radius: 5px;
  }
}

@keyframes rotate {
  100% {
    transform: rotate(1turn);
  }
}

.lds-ring div {
  box-sizing: border-box;
  display: block;
  position: absolute;
  width: 364px;
  height: 364px;
  margin: 8px;
  border: 20px solid #fff;
  border-radius: 50%;
  animation: lds-ring 1.2s cubic-bezier(0.5, 0, 0.5, 1) infinite;
  border-color: #fff transparent transparent transparent;
  bottom: 50%;
  right: 32%;
}

.lds-ring div:nth-child(1) {
  animation-delay: -0.45s;
}

.lds-ring div:nth-child(2) {
  animation-delay: -0.3s;
}

.lds-ring div:nth-child(3) {
  animation-delay: -0.15s;
}

@keyframes lds-ring {
  0% {
    transform: rotate(0deg);
  }

  100% {
    transform: rotate(360deg);
  }
}
</style>
