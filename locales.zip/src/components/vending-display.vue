<template>
  <div class="flex flex-col items-center justify-center gap-2 flex-grow">
    <div v-for="row of config.rows" :key="row" class="flex gap-1 h-1/5">
      <div
        v-for="item of itemRows[row - 1]" :key="item.id"
        class="bg-dark-300/50 flex-grow-0 flex-shrink-0 rounded-md p-1"
        :style="{width: (item.numCol * config.slotWidthPx + (item.numCol - 1) * config.slotGapPx) + 'px'}"
        @click="onClick(item, row - 1, item.col)"
      >
        <slot name="item" :item="item" :product="productFind(item)">
          {{ item }}
        </slot>
      </div>
    </div>
  </div>
</template>
<script>
import { useMasterStore } from '../store/master-store'
import { useUiStore } from '../store/ui-store'
export default {
  props: {
    config: {
      type: Object,
      default() {
        return {
          rows: 5,
          cols: 24,
          slotWidthMm: 28,
          slotLongMm: 470,
          slotGapMm: 1,
          slotWidthPx: 40,
          slotGapPx: 4,
        }
      },
    },
    items: {
      type: Array,
      default() {
        return [
          { productId: 0, start: 0, list: 0, end: 0, row: 0 },
        ]
      },
    },
  },
  emits: [
    'item-click',
  ], //
  data() {
    const masterStore = useMasterStore()
    return {
      masterStore,
      itemsDetail: [],
    }
  },
  computed: {
    products() {
      return this.masterStore.products
    },
    itemLookup() {
      let out = {}
      for (const item of this.items) {
        out[`${item.row}:${item.col}`] = item
      }
      return out
    },
    itemRows() {
      let out = []
      for (let row = 0; row < this.config.rows; row++) {
        let list = []
        for (let col = 0; col < this.config.cols; col++) {
          let item = this.itemLookup[`${row}:${col}`]
          if (!item) {
            list.push({ productId: 0, row, col, list: 0, numCol: 1 })
          } else {
            let product = this.products.find(x => x.id === item.productId)
            let sum = Math.ceil(product.config.widthMm / this.config.slotWidthMm)
            item.numCol = sum
            list.push(item)
            col += (sum) - 1
          }
        }
        out.push(list)
      }
      return out
    },
  },

  methods: {
    onClick(item, row, col) {
      this.$emit('item-click', { item, row, col })
    },
    productFind(item) {
      let prod = this.masterStore.products.find(x => x.id === item.productId)
      let details = null
      if (prod) {
        details = {
          detail: prod,
          color: useUiStore().colorLevel(prod.config.category),
        }
      }
      return details
    },
  },
}
</script>
