<template>
  <div class="fixed top-0 bottom-0 left-0 right-0 h-[100vh] bg-dark-50/50">
    <div class="w-[50vh] bg-white p-1 absolute top-10 left-1/2 rounded-md" style="transform: translateX(-50%);">
      <div
        class="flex  rounded-md"
      >
        <div class="flex flex-col w-1/2  flex-grow bg-sky-200 rounded-md">
          <div
            class="flex-grow  rounded-tl-md rounded-tr-md h-60 w-full" :style="
              {
                background: `url(${selectedProduct.config.imageUrl}) center center no-repeat`,
                backgroundSize: 'cover',
              }
            "
          >
          </div>
          <div class=" flex-grow rounded-md">
            <div class="flex flex-col justify-center ">
              <p
                class="uppercase text-center "
                :style="
                  {
                    background: `${colorProduct}`,
                  }"
              >
                ระดับ: {{ selectedProduct.config.category }}
              </p>
              <div class="flex  pt-2 gap-2 ">
                <div class="flex  flex-col flex-grow gap-2 items-end uppercase">
                  <div v-for="title in titles" :key="title" class=" flex">
                    <p>{{ title }}</p>
                  </div>
                </div>
                <div class="flex  flex-col flex-grow gap-2">
                  <p>{{ selectedProduct.displayName }}</p>
                  <p>{{ selectedProduct.code }}</p>
                  <p>{{ selectedProduct.config.barcode }}</p>
                  <p>{{ stock.length }}</p>
                </div>
              </div>
            </div>
            <div class="flex flex-grow p-2 justify-center items-center">
              <button
                class="uppercase bg-black rounded-xl text-white p-2 border-light-200 border-2px shadow-md shadow-white"
                @click="changeProduct"
              >
                <p class="text-15px">
                  เปลี่ยนเวชภัณฑ์ที่บรรจุ / ย้ายที่เวชภัณฑ์
                </p>
              </button>
            </div>
          </div>
        </div>
        <div class="flex flex-col w-1/2  flex-grow bg-green-200 rounded-md">
          <div class="flex flex-col justify-center ">
            <p class="uppercase text-center  rounded-md border-5px border-dark-500 p-2 text-20px text-stroke-sm">
              ทำรายการ เพิ่ม / ลบ
            </p>
            <div class="flex gap-2 ">
              <div class="flex flex-col flex-grow">
                <div class="flex flex-col justify-center p-2 gap-2 rounded-md">
                  <div class="flex">
                    <p class="uppercase flex-grow">
                      หมายเลขล็อต:
                    </p>
                    <input class="w-1/2 flex-grow" type="text" v-model="lotNo">
                  </div>
                  <div class="flex">
                    <p class="uppercase flex-grow">
                      วันหมดอายุ:
                    </p>
                    <input class="w-1/2 flex-grow" type="date" v-model="expDate">
                  </div>
                  <div class="flex  ">
                    <p class="uppercase flex-grow">
                      จำนวน:
                    </p>
                    <input class="w-1/2 flex-grow" type="number" :min="1" :max="remainSlot" v-model="qty">
                  </div>
                  <div class="flex justify-center items-center p-2">
                    <button class=" border-green-500 border-2px text-20px p-5 rounded-md shadow-md shadow-current" @click="addItems">
                      <p>เพิ่ม</p>
                    </button>
                  </div>

                  <div class="flex flex-col ">
                    <div class="flex p-2 gap-2 bg-gray-800 flex-grow rounded-md">
                      <div class="flex justify-center w-full bg-white p-5 text-20px gap-5">
                        <p>
                          จำนวนที่สามารถเพิ่มได้ :
                        </p>
                        <p>{{ remainSlot }}</p>
                      </div>
                    </div>
                    <div v-for="(list,indexList) in stock" :key="indexList">
                      <div class="flex p-2 gap-2 justify-between  bg-gray-800 rounded-md">
                        <div class="flex flex-col  text-white uppercase">
                          <p>หมายเลขล็อต:</p>
                          <p>วันหมดอายุ:</p>
                        </div>
                        <div class="flex flex-col  text-white ">
                          <p>{{ list.lotNo }}</p>
                          <p>{{ list.expDate }}</p>
                        </div>
                        <div class="flex justify-center items-center">
                          <div
                            class="w-[40px] h-[40px] rounded-full flex justify-center items-center right-20"
                            :class="[ uiStore.compareColor({exp:list.expDate,selectedProduct}) ]"
                          >
                            <div class="m-icon text-40px">
                              priority_high
                            </div>
                          </div>
                        </div>
                        <div class="flex justify-center items-center">
                          <button
                            class="rounded-full bg-white flex  h-10 w-10 justify-center items-center"
                            @click="doRemove(indexList)"
                          >
                            <div class="m-icon">
                              remove
                            </div>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="flex justify-center gap-10 p-2">
        <div class="bg-green-400 rounded-md p-2  shadow-md shadow-black">
          <button @click="confirmSlot">
            บันทึก
          </button>
        </div>
        <div class="bg-yellow-400 rounded-md p-2  shadow-md shadow-black">
          <button @click="resetSlot">
            ยกเลิก
          </button>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import dayjs from 'dayjs'
import { useMasterStore } from '../store/master-store'
import { useUiStore } from '../store/ui-store'
import { mapState } from 'pinia'
import { useAppStore } from '@/store/app-store'
export default {
  props: {
    vendingItem: {
      type: Object,
    },
  },
  emits: ['close', 'confirmSlot', 'changing', 'reset'], //
  data() {
    let masterStore = useMasterStore()
    let uiStore = useUiStore()
    let stock = this.vendingItem.list.slice(0)
    let items = JSON.parse(JSON.stringify(this.vendingItem))
    stock.sort((a, b) => Date.parse(a.expDate) - Date.parse(b.expDate)).reverse()
    let titles = ['ขื่อ : ', 'หมายเลขวัสดุ : ', 'บาร์โค้ด : ', 'จำนวน : ']
    return {
      stock,
      masterStore,
      uiStore,
      lotNo: '',
      expDate: '',
      qty: 1,
      titles,
      items,
    }
  }, //
  computed: {
    ...mapState(useAppStore, ['projectCode', 'vendingCode']),
    vending() {
      return this.masterStore.vendings.find(x => x.code === this.vendingCode)
    },
    selectedProduct() {
      return this.masterStore.products.find(x => x.id === this.items.productId)
    },
    maxItemInSlot() {
      return Math.floor(this.vending.config.slotLongMm / this.selectedProduct.config.longMm)
    },
    remainSlot() {
      return this.maxItemInSlot - this.stock.length
    },
    colorProduct() {
      return useUiStore().colorLevel(this.selectedProduct.config.category)
    },
  },
  created() {
  },
  methods: {
    addItems() {
      // todo validate lotnum not null
      // qty > 0  < remain
      // expdate is not null and not expired
      let now = dayjs().format()
      if (this.remainSlot <= 0) {
        return
      }
      if (this.expDate === null) {
        return
      }
      if (this.expDate < now) {
        return
      }
      for (let i = 0; i < this.qty; i++) {
        this.stock.push({
          lotNo: this.lotNo,
          expDate: this.expDate,
        })
      }
      this.stock.sort((a, b) => Date.parse(a.expDate) - Date.parse(b.expDate)).reverse()
    },
    resetSlot() {
      this.stock = this.vendingItem.list.slice(0)
    },
    confirmSlot() {
      this.$emit('close', this.stock)
    },
    doRemove(index) {
      // todo confirm
      this.stock.splice(index, 1)
    },
    changeProduct() {
      this.$emit('changing', this.selectedProduct)
    },

  },
}
</script>
