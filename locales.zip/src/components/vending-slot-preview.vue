<template>
  <div class="fixed top-0 bottom-0 left-0 right-0 h-[100vh] bg-dark-50/50" @click="close">
    <div class="w-[50vh] bg-white p-1 absolute top-30 left-1/2 rounded-md" style="transform: translateX(-50%);">
      <div class="flex flex-col w-full ">
        <div class="flex  h-full bg-gray-500 p-2 gap-2 rounded-md">
          <div class="flex flex-col w-1/2">
            <div
              class="rounded-tl-md rounded-tr-md h-80 w-full" :style="
                {
                  background: `url(${selectedProduct.config.imageUrl}) center center no-repeat`,
                  backgroundSize: 'cover',
                }
              "
            >
            </div>
            <p
              class="uppercase text-center h-10 flex justify-center items-center border-solid border-5px border-black"
              :style="
                {
                  background: `${colorProduct}`,
                }"
            >
              ระดับ: {{ selectedProduct.config.category }}
            </p>
            <div class="flex  pt-2 gap-2 bg-white  items-center flex-grow rounded-bl-md rounded-br-md">
              <div class="flex  flex-col flex-grow gap-2 items-end uppercase p-2">
                <div v-for="title in titles" :key="title" class=" flex">
                  <p>{{ title }}</p>
                </div>
              </div>
              <div class="flex  flex-col flex-grow gap-2">
                <p>{{ selectedProduct.displayName }}</p>
                <p>{{ selectedProduct.code }}</p>
                <p>{{ selectedProduct.config.barcode }}</p>
                <p>{{ stock.length }}</p>
              </div>
            </div>
          </div>

          <div class="flex flex-col w-1/2  gap-2 rounded-tl-md rounded-tr-md">
            <div class="flex justify-center border-solid border-5px w-full rounded-md text-20px p-2 bg-white border-black">
              <p>รายการที่มีในช่อง</p>
            </div>

            <div v-for="(list,indexList) in stock" :key="indexList" class="flex items-center justify-center flex-grow bg-gray-200 rounded-md">
              <div class="flex p-2 gap-2 justify-center w-full ">
                <div class="flex flex-col  uppercase items-end">
                  <p>หมายเลขล็อต:</p>
                  <p>วันหมดอายุ:</p>
                </div>
                <div class="flex flex-col">
                  <p>{{ list.lotNo }}</p>
                  <p>{{ list.expDate }}</p>
                </div>
                <div
                  class="absolute w-[40px] h-[40px] rounded-full flex justify-center items-center right-10"
                  :class="[ uiStore.compareColor({exp:list.expDate,selectedProduct}) ]"
                >
                  <div class="m-icon text-40px">
                    priority_high
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import dayjs from 'dayjs'
import { useMasterStore } from '../store/master-store'
import { useUiStore } from '../store/ui-store'
import { mapState } from 'pinia'
import { useAppStore } from '@/store/app-store'
export default {
  props: {
    selectItem: {
      type: Object,
    },
  },
  emits: ['close', 'confirmSlot', 'changing', 'reset', 'close-preview'], //
  data() {
    let masterStore = useMasterStore()
    const uiStore = useUiStore()
    let stock = this.selectItem.list.slice(0)
    let items = JSON.parse(JSON.stringify(this.selectItem))
    stock.sort((a, b) => Date.parse(a.expDate) - Date.parse(b.expDate)).reverse()
    let titles = ['ขื่อ : ', 'หมายเลขวัสดุ : ', 'บาร์โค้ด : ', 'จำนวน : ']
    return {
      stock,
      masterStore,
      uiStore,
      lotNo: '',
      expDate: '',
      qty: 1,
      titles,
      items,
    }
  }, //
  computed: {
    ...mapState(useAppStore, ['projectCode', 'vendingCode']),
    project() {
      return this.masterStore.projects.find(element => element.code === this.projectCode)
    },
    vending() {
      return this.masterStore.vendings.find(x => x.code === this.vendingCode)
    },
    selectedProduct() {
      return this.masterStore.products.find(x => x.id === this.items.productId)
    },
    colorProduct() {
      return useUiStore().colorLevel(this.selectedProduct.config.category)
    },

  },
  created() {
  },
  methods: {
    close() {
      this.$emit('close-preview')
    },

  },
}
</script>
