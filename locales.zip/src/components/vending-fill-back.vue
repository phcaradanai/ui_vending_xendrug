<template>
  <div
    class="w-full bg-black/80 absolute top-[76%] left-1/2  p-5 flex justify-center h-[24vh] items-start overflow-auto hideScroll" style="transform: translateX(-50%);"
    @click="cancelFillBack"
  >
    <div class="flex flex-col justify-end w-[90%]">
      <div
        class="p-5 bg-cyan-200 flex justify-center "
        :style="
          {
            borderRadius:'20px 20px 0 0'
          }
        "
      >
        <p class="text-30px">
          เลือกช่องว่างที่ต้องการ
        </p>
      </div>

      <div class="bg-cyan-300 p-2 flex justify-center">
        <p class="text-20px">
          รายการของที่มี
        </p>
      </div>
      <div v-for="(item,k) in slotItem" :key="k">
        <div class="flex gap-2 p-2 bg-white  flex justify-center rounded-md">
          <p>หมายเลขล็อต {{ item.lotNo }}</p>
          <p>วันหมดอายุ {{ item.expDate }}</p>
        </div>
      </div>
      <div class="absolute rounded-full p-4 right-18 top-4">
        <button @click="cancelFillBack">
          <div class="m-icon text-50px text-stroke-md bg-white rounded-full">
            close
          </div>
        </button>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    vendingItem: {
      type: Object,
    },
  },
  emits: ['cancelFillBack'],
  data() {
    return {
    }
  },
  computed: {
    slotItem() {
      return this.vendingItem.list
    },
  },
  methods: {
    cancelFillBack() {
      this.$emit('cancelFillBack')
    },
  },
}
</script>

<style>
.hideScroll::-webkit-scrollbar {
  display: none;
}</style>
