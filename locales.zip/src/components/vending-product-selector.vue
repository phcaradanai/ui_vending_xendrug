<template>
  <div class="w-[50vh] bg-gray-50 absolute top-10 left-1/2 rounded-xl" style="transform: translateX(-50%);">
    <button
      type="submit" class="flex absolute justify-center items-center bg-red-300 right-2 rounded-full top-2"
      @click="confirmSlot"
    >
      <div class="m-icon text-50px">
        close
      </div>
    </button>
    <div v-if="onFilter" class="flex flex-col justify-center items-center p-5  gap-5 h-full text-20px">
      <div>
        <p>ต้องการย้ายที่ของเวชภัณฑ์เดิมหรือไหม</p>
      </div>
      <div class="flex gap-5">
        <button class="bg-green-300 p-5 rounded-md" @click="openFillBack">
          ใช่ ต้องการ
        </button>
        <button class="bg-red-300 p-5 rounded-md" @click="closeFilter">
          ไม่ ต้องการ
        </button>
      </div>
    </div>
    <div v-if="!onFilter" class="flex flex-col justify-center items-center p-5 gap-5">
      <div class="m-icon text-50px">
        qr_code_scanner
      </div>
      <div class="flex  text-40px">
        สแกน QR CODE เพื่อระบุตัวเวชภัณฑ์
      </div>

      <div class="flex w-1/2">
        <div class="flex flex-grow">
          <input class="searchTerm flex-grow" type="text" placeholder="What are you looking for?" v-model="searchText">
        </div>
        <button type="submit" class="searchButton flex justify-center items-center" @click="searchActive(searchText)">
          <div class="m-icon">
            search
          </div>
        </button>
      </div>
      <div v-if="!searchOn" class="flex w-full p-5 gap-5 overflow-auto">
        <button
          v-for="prod in productCanChange" :key="prod.id" class="w-1/3 h-80 flex flex-col items-center "
          @click="clickChanger(prod)"
        >
          <div
            class="h-full w-full rounded-md" :style="
              {
                background: `url(${prod.config.imageUrl}) center center no-repeat`,
                backgroundSize: 'cover',
              }"
          >
          </div>
          <div>
            <p>{{ prod.displayName }}</p>
          </div>
        </button>
      </div>
      <div v-else class="flex w-full p-5 gap-5 overflow-auto">
        <button
          v-for="prod in searchItem" :key="prod.id" class="w-1/3 h-80 flex flex-col items-center "
          @click="clickChanger(prod)"
        >
          <div
            class="h-full w-full rounded-md" :style="
              {
                background: `url(${prod.config.imageUrl}) center center no-repeat`,
                backgroundSize: 'cover',
              }"
          >
          </div>
          <div>
            <p>{{ prod.displayName }}</p>
          </div>
        </button>
      </div>
    </div>
  </div>
</template>

<script>
import { useUiStore } from '../store/ui-store'
import { useMasterStore } from '../store/master-store'
import { MqttClient } from '@/lib/mqtt'
import { mapState } from 'pinia'
import { useAppStore } from '@/store/app-store'

export default {
  props: {
    changeProduct: {
      type: Object,
      default() {
        return {}
      },
    },

  },
  emits: ['close', 'changed', 'doFillBack'],
  data() {
    const masterStore = useMasterStore()
    let oldProduct = JSON.parse(JSON.stringify(this.changeProduct))
    return {
      searchOn: false,
      onFilter: true,
      searchItem: [],
      searchText: '',
      oldProduct,
      masterStore,
    }
  },
  computed: {
    ...mapState(useAppStore, ['projectCode', 'vendingCode']),
    vending() {
      return this.masterStore.vendings.find(x => x.code === this.vendingCode)
    },
    products() {
      return this.masterStore.products
    },
    productCanChange() {
      return this.compareOldAndAll()
    },
  },
  mounted() {
    if (!this.changeProduct) {
      this.onFilter = !this.onFilter
    }
    this.mqttClient = MqttClient('default', {})
    this.confirmProductTopic = `xd/${this.projectCode}/${this.vendingCode}/reader`
    this.confirmProductSubId = this.mqttClient.subscribe(this.confirmProductTopic, async (topic, payload) => {
      console.log('GOT', payload)
      if (payload.refType === 'product') {
        this.doChanger(payload)
      }
    })
  },
  unmounted() {
    this.mqttClient.unsubscribe(this.confirmProductTopic, this.confirmProductSubId)
  },
  methods: {
    searchActive(text) {
      this.searchOn = !this.searchOn
      this.productCanChange.forEach(element => {
        let upper = element.displayName.toUpperCase()
        if (upper.indexOf(text.toUpperCase()) > -1) {
          this.searchItem.push(element)
        }
      })
    },
    closeFilter() {
      this.onFilter = !this.onFilter
    },
    confirmSlot() {
      this.$emit('close')
    },
    doChanger(product) {
      // todo confirm to save
      // wait for confirm  scan 2 id
      let productSelected = this.masterStore.products.find(x => x.code === product.refCode)
      if (this.oldProduct) {
        if (product.refId !== this.oldProduct.id) {
          let selected = Math.ceil(productSelected.config.widthMm / this.vending.config.slotWidthMm)
          let oldSelected = Math.ceil(this.oldProduct.config.widthMm / this.vending.config.slotWidthMm)
          if (selected <= oldSelected) {
            this.$emit('changed', { product: productSelected, type: 1 })
          }
        }
      } else {
        this.$emit('changed', { product: productSelected, type: 0 })
      }
    },
    clickChanger(prod) {
      // todo confirm to save
      // wait for confirm  scan 2 id

      if (this.oldProduct) {
        let selected = Math.ceil(prod.config.widthMm / this.vending.config.slotWidthMm)
        let oldSelected = Math.ceil(this.oldProduct.config.widthMm / this.vending.config.slotWidthMm)
        if (selected <= oldSelected) {
          useUiStore().cancelConfirmProduct()
          this.$emit('changed', { product: prod, type: 1 })
        }
      } else {
        useUiStore().cancelConfirmProduct()
        this.$emit('changed', { product: prod, type: 0 })
      }

      // await this.doSave(product)
    },
    compareOldAndAll() {
      let canChangeProducts = []
      if (this.oldProduct) {
        this.masterStore.products.forEach(element => {
          if (element.id !== this.oldProduct.id) {
            let selected = Math.ceil(element.config.widthMm / this.vending.config.slotWidthMm)
            let oldSelected = Math.ceil(this.oldProduct.config.widthMm / this.vending.config.slotWidthMm)
            if (selected <= oldSelected) {
              canChangeProducts.push(element)
            }
          }
        })
      } else {
        canChangeProducts = this.masterStore.products.slice(0)
      }
      return canChangeProducts
    },
    openFillBack() {
      this.$emit('doFillBack')
      this.$emit('close')
    },

  },
}
</script>
<style>
.searchTerm {
  width: 100%;
  border: 3px solid #00B4CC;
  border-right: none;
  padding: 5px;
  height: 36px;
  border-radius: 5px 0 0 5px;
  outline: none;
  color: #9DBFAF;
}

.searchButton {
  width: 40px;
  height: 36px;
  border: 1px solid #00B4CC;
  background: #00B4CC;
  text-align: center;
  color: #fff;
  border-radius: 0 5px 5px 0;
  cursor: pointer;
  font-size: 20px;
}
</style>
